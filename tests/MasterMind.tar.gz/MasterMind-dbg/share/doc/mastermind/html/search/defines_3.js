var searchData=
[
  ['sdl_5fprint_5fcenter',['sdl_print_center',['../sdl_8c.html#a06e161aed336e7db4377098f0aa85eab',1,'sdl.c']]],
  ['sdl_5fprint_5fleft',['sdl_print_left',['../sdl_8c.html#a2d24fc00152ccfdf0b7949482c9ca0ce',1,'sdl.c']]]
];
