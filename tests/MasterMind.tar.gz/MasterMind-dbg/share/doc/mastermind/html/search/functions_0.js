var searchData=
[
  ['clean',['clean',['../sdl_8c.html#a2bbe646c052baf99f04a367ef6031d74',1,'sdl.c']]]
];
