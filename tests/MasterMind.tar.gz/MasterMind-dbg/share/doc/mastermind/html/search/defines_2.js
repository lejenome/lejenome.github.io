var searchData=
[
  ['package',['PACKAGE',['../config_8h.html#aca8570fb706c81df371b7f9bc454ae03',1,'config.h']]],
  ['program_5fname',['PROGRAM_NAME',['../config_8h.html#a3b6a35b8be8405a9db72cc5dea97954b',1,'config.h']]],
  ['program_5furl',['PROGRAM_URL',['../config_8h.html#a1db21a0a4e4cfe93545288fa7aa47b49',1,'config.h']]],
  ['program_5fversion',['PROGRAM_VERSION',['../config_8h.html#a2f10abd650e471fae2d7e8c63d41206a',1,'config.h']]]
];
