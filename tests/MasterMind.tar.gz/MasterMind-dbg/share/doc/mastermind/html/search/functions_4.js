var searchData=
[
  ['init_5fsdl',['init_sdl',['../sdl_8c.html#a02b747ee9a45485dd694783af494b4f9',1,'sdl.c']]],
  ['initcolors',['initColors',['../sdl_8c.html#abd1f8c83fcebf1f40bc3fec0f96fb2bb',1,'sdl.c']]],
  ['inittables',['initTables',['../sdl_8c.html#a6a3745a608949257cc9c8dcd35bb6e72',1,'sdl.c']]],
  ['iter',['iter',['../sdl_8c.html#a9335580825ed984e6db28146e9abbf7c',1,'sdl.c']]]
];
