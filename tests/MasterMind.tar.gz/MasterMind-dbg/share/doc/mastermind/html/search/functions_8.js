var searchData=
[
  ['redraw',['redraw',['../sdl_8c.html#ab396718daaebb64c60262944a5e28755',1,'sdl.c']]],
  ['redraw_5fgame',['redraw_game',['../sdl_8c.html#ac655bfb4bb559bb214efae3afc9b0bf5',1,'sdl.c']]],
  ['redraw_5fsettings',['redraw_settings',['../sdl_8c.html#ae26ebed3f9fbf3be814db971ae3d2d4e',1,'sdl.c']]]
];
