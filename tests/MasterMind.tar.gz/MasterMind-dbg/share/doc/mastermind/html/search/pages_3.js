var searchData=
[
  ['learning_20sources',['Learning sources',['../md_doc_learn.html',1,'']]]
];
