var searchData=
[
  ['drawguess',['drawGuess',['../sdl_8c.html#a7a2b90c24baef6ca65de2fa2e695126f',1,'sdl.c']]],
  ['drawsecret',['drawSecret',['../sdl_8c.html#a41b336f4c0ecffbba9c3a6fa039cdc5e',1,'sdl.c']]]
];
