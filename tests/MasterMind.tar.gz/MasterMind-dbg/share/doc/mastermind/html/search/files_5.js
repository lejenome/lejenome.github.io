var searchData=
[
  ['sdl_2ec',['sdl.c',['../sdl_8c.html',1,'']]],
  ['solarized_5fdark_2eh',['solarized_dark.h',['../solarized__dark_8h.html',1,'']]],
  ['solarized_5flight_2eh',['solarized_light.h',['../solarized__light_8h.html',1,'']]]
];
