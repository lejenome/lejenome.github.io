var searchData=
[
  ['sdl_5fprint',['sdl_print',['../sdl_8c.html#ab6e622ce53aba293afc6c2333165e7c4',1,'sdl.c']]],
  ['sdl_5fprint_5ficon',['sdl_print_icon',['../sdl_8c.html#a2b9393a1eb25fe87fc1aa9bfafa1921f',1,'sdl.c']]],
  ['setbg',['setBg',['../sdl_8c.html#ac2142b0c1af20677189b15fbe5d26c4c',1,'sdl.c']]]
];
