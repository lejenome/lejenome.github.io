var searchData=
[
  ['max',['max',['../structmm__scores__t.html#ae1042f2cad73890613cd8365c9318587',1,'mm_scores_t::max()'],['../structmm__conf__int__t.html#a766336f600b423d33eb75b10d651ea7f',1,'mm_conf_int_t::max()']]],
  ['min',['min',['../structmm__conf__int__t.html#ab508cc5da59fe63910b7ca310620c155',1,'mm_conf_int_t']]]
];
