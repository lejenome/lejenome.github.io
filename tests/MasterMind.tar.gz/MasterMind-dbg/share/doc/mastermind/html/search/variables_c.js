var searchData=
[
  ['remise',['remise',['../structmm__config.html#a881aeec9003a50b0103b3e1dd0a99604',1,'mm_config']]],
  ['rend',['rend',['../sdl_8c.html#a080b8af7bfa0f8d3382d63e1023f862e',1,'sdl.c']]],
  ['rows',['rows',['../structSDL__Table.html#ad0e28053f609a96d86cdb18ca1018507',1,'SDL_Table']]]
];
