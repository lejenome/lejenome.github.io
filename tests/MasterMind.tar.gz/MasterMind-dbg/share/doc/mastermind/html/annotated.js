var annotated =
[
    [ "cmd_t", "structcmd__t.html", "structcmd__t" ],
    [ "mm_conf_bool_t", "structmm__conf__bool__t.html", "structmm__conf__bool__t" ],
    [ "mm_conf_int_t", "structmm__conf__int__t.html", "structmm__conf__int__t" ],
    [ "mm_conf_str_t", "structmm__conf__str__t.html", "structmm__conf__str__t" ],
    [ "mm_conf_t", "unionmm__conf__t.html", "unionmm__conf__t" ],
    [ "mm_config", "structmm__config.html", "structmm__config" ],
    [ "mm_guess", "structmm__guess.html", "structmm__guess" ],
    [ "mm_score_t", "structmm__score__t.html", "structmm__score__t" ],
    [ "mm_scores_t", "structmm__scores__t.html", "structmm__scores__t" ],
    [ "mm_secret", "structmm__secret.html", "structmm__secret" ],
    [ "mm_session", "structmm__session.html", "structmm__session" ],
    [ "SDL_Table", "structSDL__Table.html", "structSDL__Table" ]
];