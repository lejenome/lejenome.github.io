var cli_8c =
[
    [ "getCombination", "cli_8c.html#abc3f0cb869413f267dd711a8f3961c33", null ],
    [ "main", "cli_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "parseBuf", "cli_8c.html#aa50f743a2d36776585c9463a78afd695", null ],
    [ "printPanel", "cli_8c.html#aab580ebeb59e4315574907f2b26e1afc", null ],
    [ "cmds", "cli_8c.html#a0607dff31f6561120a477fba0c7cb7cd", null ],
    [ "session", "cli_8c.html#acc62da0f6c0b1a0ba609534c9b4b4bcf", null ]
];