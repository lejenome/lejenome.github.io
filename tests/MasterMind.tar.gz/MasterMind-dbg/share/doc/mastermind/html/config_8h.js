var config_8h =
[
    [ "FONTSDIR", "config_8h.html#af62a7dbf4ed4bad78fa4459b8ffb7dd9", null ],
    [ "ICONSDIR", "config_8h.html#ab911e31660c26fb6996244e7aaf6bd45", null ],
    [ "LOCALEDIR", "config_8h.html#ab2cb7816c01560f1bab8b2dbd94be4c8", null ],
    [ "MM_COLORS", "config_8h.html#a1f29fa0d816adb4259eea64dca98cc51", null ],
    [ "MM_COLORS_MAX", "config_8h.html#af3a56b3100aee4c97bf77f37ab88450e", null ],
    [ "MM_GUESSES", "config_8h.html#a2abec0113bbe6f6ce6dbb2b2e5e2c11e", null ],
    [ "MM_GUESSES_MAX", "config_8h.html#a085dd75c1536f92c6ecf84bb5427892d", null ],
    [ "MM_HOLES", "config_8h.html#ae636196b9816ec9c75bec912900de34b", null ],
    [ "MM_HOLES_MAX", "config_8h.html#a05c76ec63ab566d4c981fd693c763d4b", null ],
    [ "PACKAGE", "config_8h.html#aca8570fb706c81df371b7f9bc454ae03", null ],
    [ "PROGRAM_NAME", "config_8h.html#a3b6a35b8be8405a9db72cc5dea97954b", null ],
    [ "PROGRAM_URL", "config_8h.html#a1db21a0a4e4cfe93545288fa7aa47b49", null ],
    [ "PROGRAM_VERSION", "config_8h.html#a2f10abd650e471fae2d7e8c63d41206a", null ]
];