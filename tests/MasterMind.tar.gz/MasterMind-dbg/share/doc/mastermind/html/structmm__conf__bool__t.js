var structmm__conf__bool__t =
[
    [ "name", "structmm__conf__bool__t.html#ac2cb2432d0efed922f4eeef373642d84", null ],
    [ "type", "structmm__conf__bool__t.html#acec01ec223a508e9b08d86e894bb2d70", null ],
    [ "val", "structmm__conf__bool__t.html#ac3294319047890f071c595f4e7e592eb", null ]
];