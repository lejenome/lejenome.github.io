var solarized__dark_8h =
[
    [ "bg_black", "solarized__dark_8h.html#a735aa10c28a1ebcfd7afe9fc9f5cb16b", null ],
    [ "bg_blue", "solarized__dark_8h.html#a87edafa09d85099b291bbc9da59715f1", null ],
    [ "bg_color", "solarized__dark_8h.html#ae53362ed20e307ffed689dd9acdbb871", null ],
    [ "bg_cyan", "solarized__dark_8h.html#af2df6acc3e33185212fff488b35d4c18", null ],
    [ "bg_green", "solarized__dark_8h.html#a59ed1bc30e2bfff301e45cdc37a678cd", null ],
    [ "bg_magenta", "solarized__dark_8h.html#aeda80b43a4b9a8d815c35ba253c16bc0", null ],
    [ "bg_red", "solarized__dark_8h.html#a847eb8beed1f78ab7af0bcfdbfc37395", null ],
    [ "bg_white", "solarized__dark_8h.html#a12d0ca71d9dfe8d6aeeb84b64191e6af", null ],
    [ "bg_yellow", "solarized__dark_8h.html#ad4e2c770b3200bb112c24bddcbd61004", null ],
    [ "br_color", "solarized__dark_8h.html#ac9096fa446377a6dfff21853115c259d", null ],
    [ "fg_black", "solarized__dark_8h.html#a1d1ca7c1f063accfbf07992c7e425f28", null ],
    [ "fg_blue", "solarized__dark_8h.html#ad5fef2dbd88e699620e4dc5a4fdff296", null ],
    [ "fg_color", "solarized__dark_8h.html#a49adcffce4a87fe94474082773798733", null ],
    [ "fg_cyan", "solarized__dark_8h.html#a5c0f22cf8a1072da0a272e441dde960c", null ],
    [ "fg_green", "solarized__dark_8h.html#aef2ffa39ad1309ea192fea91f9d03958", null ],
    [ "fg_magenta", "solarized__dark_8h.html#a98311c56e549e9739597537eeb590cd5", null ],
    [ "fg_red", "solarized__dark_8h.html#a8dbdee2aa3cbe3f8868aa5bb85e2f81c", null ],
    [ "fg_white", "solarized__dark_8h.html#a63eb311c8fd5e7be62518ee0dd17b315", null ],
    [ "fg_yellow", "solarized__dark_8h.html#a1f19d9717c1d2363830001aab71839ae", null ]
];