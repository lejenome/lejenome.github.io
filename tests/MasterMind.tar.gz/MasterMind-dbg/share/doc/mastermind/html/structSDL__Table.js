var structSDL__Table =
[
    [ "cols", "structSDL__Table.html#a6783f5be756fceb1fc8af0983decf2e6", null ],
    [ "h", "structSDL__Table.html#a33aa7659a0107b4904169820affb84c4", null ],
    [ "rows", "structSDL__Table.html#ad0e28053f609a96d86cdb18ca1018507", null ],
    [ "w", "structSDL__Table.html#a7426b32284ff8a9284aca7c3d00512c4", null ],
    [ "x", "structSDL__Table.html#ad447fc1e89e1f0d237d53b331615cbe1", null ],
    [ "y", "structSDL__Table.html#a5d65a9d312f16f109bb3a4a98c6de896", null ]
];