var structmm__score__t =
[
    [ "account", "structmm__score__t.html#a465bf89d9c5999203b8fc0185f762fbe", null ],
    [ "score", "structmm__score__t.html#ad7a86bd8fdf52c4a30a28248851799ff", null ]
];