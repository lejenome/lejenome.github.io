var files =
[
    [ "colorscheme", "dir_d2cd590ba66a6a55ee57a96cec8d493d.html", "dir_d2cd590ba66a6a55ee57a96cec8d493d" ],
    [ "config.h", "config_8h.html", "config_8h" ],
    [ "cli-cmd.c", "cli-cmd_8c.html", "cli-cmd_8c" ],
    [ "cli-cmd.h", "cli-cmd_8h.html", "cli-cmd_8h" ],
    [ "cli.c", "cli_8c.html", "cli_8c" ],
    [ "core.c", "core_8c.html", "core_8c" ],
    [ "core.h", "core_8h.html", "core_8h" ],
    [ "lib.c", "lib_8c.html", "lib_8c" ],
    [ "lib.h", "lib_8h.html", "lib_8h" ],
    [ "sdl.c", "sdl_8c.html", "sdl_8c" ]
];