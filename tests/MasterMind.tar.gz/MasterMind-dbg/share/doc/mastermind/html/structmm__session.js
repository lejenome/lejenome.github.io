var structmm__session =
[
    [ "account", "structmm__session.html#acf03a0e78680e863bc1aa736c5da18be", null ],
    [ "config", "structmm__session.html#a6cc73f7654ddde1691d5c16400fe7b31", null ],
    [ "guessed", "structmm__session.html#ae2250c6fc1c09a2ce4bdb73b25920305", null ],
    [ "panel", "structmm__session.html#a0b6885a86fa07e3385a42b70c5258728", null ],
    [ "secret", "structmm__session.html#a700cd2296e86dcea6977184472139496", null ],
    [ "state", "structmm__session.html#af1b0800e581571f12e286edb48514952", null ]
];