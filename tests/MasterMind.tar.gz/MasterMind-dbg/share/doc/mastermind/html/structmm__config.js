var structmm__config =
[
    [ "colors", "structmm__config.html#acb695404b78bb9b4870e683790efb0d7", null ],
    [ "guesses", "structmm__config.html#a589637bad802b3e2a32ae808d6642ec4", null ],
    [ "holes", "structmm__config.html#aba0eca7bb5928111f0f436cf5f6fd657", null ],
    [ "remise", "structmm__config.html#a881aeec9003a50b0103b3e1dd0a99604", null ]
];