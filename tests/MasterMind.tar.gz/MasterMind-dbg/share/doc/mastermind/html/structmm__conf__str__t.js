var structmm__conf__str__t =
[
    [ "len", "structmm__conf__str__t.html#ac80aeec87e1c8d72f0980fcb6bffee0d", null ],
    [ "name", "structmm__conf__str__t.html#ab50d9cace65e0bf0c467a92f7209e43e", null ],
    [ "type", "structmm__conf__str__t.html#aea7bd2c53ad75606227f5a610b4aeb89", null ],
    [ "val", "structmm__conf__str__t.html#ae221512d43ee8b9e86ee45a9d5bbaf3b", null ]
];