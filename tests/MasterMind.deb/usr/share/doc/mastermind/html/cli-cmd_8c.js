var cli_cmd_8c =
[
    [ "cmd_account", "cli-cmd_8c.html#a8abc82c88d5c542726b042c29a793df8", null ],
    [ "cmd_help", "cli-cmd_8c.html#a2f7b102107ed187402883ff1ecda288a", null ],
    [ "cmd_quit", "cli-cmd_8c.html#aee6a48f0b7c61ba338041743cd3b3926", null ],
    [ "cmd_restart", "cli-cmd_8c.html#a1926779679901214b810bc374e8b53d5", null ],
    [ "cmd_savegame", "cli-cmd_8c.html#a2964dd0ad23daeb017d43062c4c4e0e5", null ],
    [ "cmd_score", "cli-cmd_8c.html#a2960196a54c1333fcfdee96410a73314", null ],
    [ "cmd_set", "cli-cmd_8c.html#acda03fec31db29cb270568d020fe77ef", null ],
    [ "cmd_version", "cli-cmd_8c.html#a418ae8c771787e4cecd18c2b02663879", null ],
    [ "execArgs", "cli-cmd_8c.html#a7296ef5a92893bdbadedc9381415ed9b", null ],
    [ "mm_cmd_mode", "cli-cmd_8c.html#a6c89522195c3b994d79a0e6819961cb5", null ]
];