var structmm__scores__t =
[
    [ "len", "structmm__scores__t.html#a5852c21742617c55675dbfa67569eaa6", null ],
    [ "max", "structmm__scores__t.html#ae1042f2cad73890613cd8365c9318587", null ],
    [ "T", "structmm__scores__t.html#ab1c19729b331714924ce311ce8d9cd16", null ]
];