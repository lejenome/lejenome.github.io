var cli_cmd_8h =
[
    [ "cmd_t", "structcmd__t.html", "structcmd__t" ],
    [ "MM_CMD_ERROR", "cli-cmd_8h.html#a44ba888f1034edc06365d4a95b734e7c", null ],
    [ "MM_CMD_MODE_CLI", "cli-cmd_8h.html#a0e2e8f616ba60854998e8ff61864114e", null ],
    [ "MM_CMD_MODE_GUI", "cli-cmd_8h.html#a6f671f36f0cbca2c2feb404afbd53000", null ],
    [ "MM_CMD_MODE_OPT", "cli-cmd_8h.html#a62a0506a5f8279abd1d45aba1bd529d5", null ],
    [ "MM_CMD_NEW_SESSION", "cli-cmd_8h.html#a79f81b01669dc5930a57380f544fa95c", null ],
    [ "MM_CMD_OPT_EXIT", "cli-cmd_8h.html#ae6309a760cbaa2d341cffb629cf615bb", null ],
    [ "MM_CMD_REDESIGN", "cli-cmd_8h.html#afccdf98ad3a05297e369ebea026c07f1", null ],
    [ "MM_CMD_SUCCESS", "cli-cmd_8h.html#a8f3e65c12ec5a6812a0eb80ed3726e88", null ],
    [ "cmd_account", "cli-cmd_8h.html#a4500c1c407611f588afc4cb31f62e3b0", null ],
    [ "cmd_help", "cli-cmd_8h.html#a896ba6380b5dd8716845728b73b21c1c", null ],
    [ "cmd_quit", "cli-cmd_8h.html#a66364ad642de65c9cca9333d87c3a8b1", null ],
    [ "cmd_restart", "cli-cmd_8h.html#a38e7b339436c935032d658002beeeb36", null ],
    [ "cmd_savegame", "cli-cmd_8h.html#a92fe30aaf1a7d43439348b9d79dc0e53", null ],
    [ "cmd_score", "cli-cmd_8h.html#ab8c21836a32556f2c691073b0ed2ad52", null ],
    [ "cmd_set", "cli-cmd_8h.html#afaf1b94903e3cb20c156225d17b35dc9", null ],
    [ "cmd_version", "cli-cmd_8h.html#a92335132fb25a03ae49326ea169d0be3", null ],
    [ "execArgs", "cli-cmd_8h.html#ad76f09549d71871e91c4247e48ac63ff", null ],
    [ "mm_cmd_mode", "cli-cmd_8h.html#a6c89522195c3b994d79a0e6819961cb5", null ]
];