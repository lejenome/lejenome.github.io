var structmm__conf__int__t =
[
    [ "max", "structmm__conf__int__t.html#a766336f600b423d33eb75b10d651ea7f", null ],
    [ "min", "structmm__conf__int__t.html#ab508cc5da59fe63910b7ca310620c155", null ],
    [ "name", "structmm__conf__int__t.html#a985241131c3e1a6d2e2e3a4a820698cc", null ],
    [ "type", "structmm__conf__int__t.html#a75e05eadd7a469525daa35ac1b83b82b", null ],
    [ "val", "structmm__conf__int__t.html#adc2e262958fba61f3820aaf9fa60b2e9", null ]
];