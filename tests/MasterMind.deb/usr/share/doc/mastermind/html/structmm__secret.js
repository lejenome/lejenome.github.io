var structmm__secret =
[
    [ "freq", "structmm__secret.html#a26cf0bfe16d66daf93cb2b718b5fe9bf", null ],
    [ "val", "structmm__secret.html#a7b71c74fb4018ac2265d483cea13300c", null ]
];