var searchData=
[
  ['configuration_20options',['Configuration options',['../md_doc_config.html',1,'']]]
];
