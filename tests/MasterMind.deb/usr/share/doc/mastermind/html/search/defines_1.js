var searchData=
[
  ['mm_5fcmd_5ferror',['MM_CMD_ERROR',['../cli-cmd_8h.html#a44ba888f1034edc06365d4a95b734e7c',1,'cli-cmd.h']]],
  ['mm_5fcmd_5fmode_5fcli',['MM_CMD_MODE_CLI',['../cli-cmd_8h.html#a0e2e8f616ba60854998e8ff61864114e',1,'cli-cmd.h']]],
  ['mm_5fcmd_5fmode_5fgui',['MM_CMD_MODE_GUI',['../cli-cmd_8h.html#a6f671f36f0cbca2c2feb404afbd53000',1,'cli-cmd.h']]],
  ['mm_5fcmd_5fmode_5fopt',['MM_CMD_MODE_OPT',['../cli-cmd_8h.html#a62a0506a5f8279abd1d45aba1bd529d5',1,'cli-cmd.h']]],
  ['mm_5fcmd_5fnew_5fsession',['MM_CMD_NEW_SESSION',['../cli-cmd_8h.html#a79f81b01669dc5930a57380f544fa95c',1,'cli-cmd.h']]],
  ['mm_5fcmd_5fopt_5fexit',['MM_CMD_OPT_EXIT',['../cli-cmd_8h.html#ae6309a760cbaa2d341cffb629cf615bb',1,'cli-cmd.h']]],
  ['mm_5fcmd_5fredesign',['MM_CMD_REDESIGN',['../cli-cmd_8h.html#afccdf98ad3a05297e369ebea026c07f1',1,'cli-cmd.h']]],
  ['mm_5fcmd_5fsuccess',['MM_CMD_SUCCESS',['../cli-cmd_8h.html#a8f3e65c12ec5a6812a0eb80ed3726e88',1,'cli-cmd.h']]],
  ['mm_5fcolors',['MM_COLORS',['../config_8h.html#a1f29fa0d816adb4259eea64dca98cc51',1,'config.h']]],
  ['mm_5fcolors_5fmax',['MM_COLORS_MAX',['../config_8h.html#af3a56b3100aee4c97bf77f37ab88450e',1,'config.h']]],
  ['mm_5fguesses',['MM_GUESSES',['../config_8h.html#a2abec0113bbe6f6ce6dbb2b2e5e2c11e',1,'config.h']]],
  ['mm_5fguesses_5fmax',['MM_GUESSES_MAX',['../config_8h.html#a085dd75c1536f92c6ecf84bb5427892d',1,'config.h']]],
  ['mm_5fholes',['MM_HOLES',['../config_8h.html#ae636196b9816ec9c75bec912900de34b',1,'config.h']]],
  ['mm_5fholes_5fmax',['MM_HOLES_MAX',['../config_8h.html#a05c76ec63ab566d4c981fd693c763d4b',1,'config.h']]]
];
